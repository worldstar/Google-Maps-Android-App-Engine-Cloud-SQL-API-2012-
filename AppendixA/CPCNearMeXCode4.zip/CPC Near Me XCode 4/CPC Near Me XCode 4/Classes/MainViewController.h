//
//  MainViewController.h
//  FooBar
//
//  Created by Shazron Abdullah on 12-01-26.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifdef PHONEGAP_FRAMEWORK
    #import <PhoneGap/PGViewController.h>
#else
    #import "PGViewController.h"
#endif

@interface MainViewController : PGViewController

@end
